
function validasiform(){
    if (document.forms["purchase-form"]["name"].value == "") {
        alert("Name cannot be empty");
        document.forms["purchase-form"]["name"].focus();
        return false;
    }
    if (document.forms["purchase-form"]["phone"].value == "") {
        alert("Phone cannot be empty");
        document.forms["purchase-form"]["phone"].focus();
        return false;
    }
    if (document.forms["purchase-form"]["email"].value == "") {
        alert("Email cannot be empty");
        document.forms["purchase-form"]["email"].focus();
        return false;
    }
    if (document.forms["purchase-form"]["age"].value == "") {
        alert("Age cannot be empty");
        document.forms["purchase-form"]["age"].focus();
        return false;
    }
    if (document.forms["purchase-form"]["distric"].value == "") {
        alert("Distric cannot be empty");
        document.forms["purchase-form"]["distric"].focus();
        return false;
    }
    if (document.forms["purchase-form"]["address"].value == "") {
        alert("Address cannot be empty");
        document.forms["purchase-form"]["address"].focus();
        return false;
    }
    if (document.forms["purchase-form"]["postal"].value == "") {
        alert("Postal Code cannot be empty");
        document.forms["purchase-form"]["postal"].focus();
        return false;
    }
    if (document.forms["purchase-form"]["notes"].value == "") {
        alert("Additional Notes cannot be empty");
        document.forms["purchase-form"]["notes"].focus();
        return false;
    }

}
